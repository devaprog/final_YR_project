from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC

class Block:
  def __init__(self, data, previous_hash):
    self.data = data
    self.previous_hash = previous_hash
    self.hash = self.calculate_hash()

  def calculate_hash(self):
    # simulate hashing with actual data
    h = hashes.Hash(hashes.SHA256())
    h.update(str(self.data).encode() + self.previous_hash.encode())
    return h.finalize().hex()

class Blockchain:
  def __init__(self):
    self.chain = [self.create_genesis_block()]

  def create_genesis_block(self):
    # create a genesis block with an arbitrary initial hash
    return Block("Genesis Block", "0")

  def get_latest_block(self):
    return self.chain[-1]

  def add_block(self, data):
    previous_block = self.get_latest_block()
    new_block = Block(data, previous_block.hash)
    self.chain.append(new_block)

# Example usage
blockchain = Blockchain()
blockchain.add_block("Transaction 1")
blockchain.add_block("Transaction 2")

# Print the blockchain
for block in blockchain.chain:
  print(f"Data: {block.data}")
  print(f"Hash: {block.hash}")
  print("----")

