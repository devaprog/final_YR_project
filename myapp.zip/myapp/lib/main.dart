import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class PollScreen extends StatefulWidget {
  @override
  _PollScreenState createState() => _PollScreenState();
}

class _PollScreenState extends State<PollScreen> {
  final int pollId = 1; // Assuming you're working with poll ID 1
  Map<String, dynamic> pollData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchPoll();
  }

  fetchPoll() async {
    var url = Uri.parse('http://10.0.2.2:5000/polls/$pollId');
    var response = await http.get(url);
    if (response.statusCode == 200) {
      setState(() {
        pollData = json.decode(response.body);
        isLoading = false;
      });
    }
  }

  sendVote(int index) async {
    var url = Uri.parse('http://10.0.2.2:5000/polls/$pollId');
    var response = await http.post(url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'vote': index}));
    if (response.statusCode == 201) {
      fetchPoll();  // Refresh the poll data after voting
    } else {
      print('Error submitting vote');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Poll')),
      body: isLoading
          ? Center(child: CircularProgressIndicator())
          : ListView(
              children: [
                Text(pollData['question'], style: TextStyle(fontSize: 24)),
                for (int i = 0; i < pollData['options'].length; i++)
                  ListTile(
                    title: Text(pollData['options'][i]),
                    leading: Radio(
                      value: i,
                      groupValue: pollData['votes'].indexOf(pollData['votes'].reduce(max)),
                      onChanged: (int? value) {
                        sendVote(i);
                      },
                    ),
                    trailing: Text('${pollData['votes'][i]} votes'),
                  ),
              ],
            ),
    );
  }
}
