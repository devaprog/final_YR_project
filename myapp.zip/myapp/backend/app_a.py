from flask import Flask, request
from flask_restful import Resource, Api
from blockchain import Blockchain  # Assuming your blockchain.py includes the necessary class definitions

app = Flask(__name__)
api = Api(app)
blockchain = Blockchain()  # Instance of your Blockchain

class Poll(Resource):
    def get(self):
        # Simple fetch to return the latest block's data, assuming it's the active poll
        latest_block = blockchain.chain[-1]
        return {'data': latest_block.data, 'hash': latest_block.hash}

    def post(self):
        data = request.get_json(force=True)
        blockchain.add_block(data['vote'])
        return {'message': 'Vote added.', 'hash': blockchain.chain[-1].hash}, 201

api.add_resource(Poll, '/poll')

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
