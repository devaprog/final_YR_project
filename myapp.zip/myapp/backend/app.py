from flask import Flask, request
from flask_restful import Resource, Api

app = Flask(__name__)
api = Api(app)

# Example data structure to hold polls
polls = {
    1: {'question': 'Favorite Color?', 'options': ['Red', 'Blue', 'Green'], 'votes': [0, 0, 0]}
}

class Poll(Resource):
    def get(self, poll_id):
        # Return the poll data
        return polls[poll_id]

    def post(self, poll_id):
        # Update the poll data with the received vote
        vote_index = request.json['vote']
        if 0 <= vote_index < len(polls[poll_id]['options']):
            polls[poll_id]['votes'][vote_index] += 1
            return {"message": "Vote added."}, 201
        return {"message": "Invalid option."}, 400

api.add_resource(Poll, '/polls/<int:poll_id>')

if __name__ == '__main__':
    app.run(debug=True)

