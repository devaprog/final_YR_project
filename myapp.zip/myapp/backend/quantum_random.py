from qiskit import QuantumCircuit, execute, Aer

def generate_quantum_random_bits(length):
    backend = Aer.get_backend('qasm_simulator')
    qc = QuantumCircuit(length, length)
    qc.h(range(length))  # Apply Hadamard gate to all qubits
    qc.measure(range(length), range(length))
    job = execute(qc, backend, shots=1, memory=True)
    result = job.result()
    random_bits = result.get_memory()[0]
    return random_bits

